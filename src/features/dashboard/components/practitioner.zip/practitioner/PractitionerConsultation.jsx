import React, { useState, useEffect } from 'react'
import { Card, Select, Button, Form, Input, Tabs, Tag, Table, Space, Radio, Divider, InputNumber, Badge, Alert } from 'antd'
import {
  UserOutlined,
  PlusOutlined,
  ClockCircleOutlined,
  FileTextOutlined,
  HeartOutlined,
  BranchesOutlined,
  DollarOutlined,
  AudioOutlined,
  CheckOutlined,
  LockOutlined,
  ExclamationCircleOutlined,
  SearchOutlined,
  BoldOutlined,
  ItalicOutlined,
  UnderlineOutlined,
  StrikethroughOutlined,
  LinkOutlined,
  UnorderedListOutlined,
  OrderedListOutlined,
  AlignLeftOutlined,
  CheckCircleFilled,
  ArrowRightOutlined,
  CopyOutlined,
  CheckCircleOutlined
} from '@ant-design/icons'
import { toast } from 'react-hot-toast'
import { useLocation } from 'react-router-dom'
import { useClinicStore } from '../../../../store/clinicStore'

const { Option } = Select
const { TextArea } = Input

export default function PractitionerConsultation() {
  const location = useLocation()
  const store = useClinicStore()
  const darkMode = store.darkMode

  // Get active simulated or actual specialty
  const activeSpecialty = store.simulatedSpecialty || 'Physiotherapist'
  const isSoapSpecialty = activeSpecialty !== 'Speech Pathologist' && activeSpecialty !== 'Speech Therapist' && activeSpecialty !== 'Occupational Therapist'

  // Extract patientId from URL query parameters if present
  const queryParams = new URLSearchParams(location.search)
  const initialPatientId = queryParams.get('patientId') || 'p1'

  const [selectedPatientId, setSelectedPatientId] = useState(initialPatientId)
  const [activeTab, setActiveTab] = useState('notes')

  // Forms
  const [soapForm] = Form.useForm()
  const [exerciseForm] = Form.useForm()
  const [referralForm] = Form.useForm()
  const [invoiceForm] = Form.useForm()

  // AI & Voice Dictation Simulation States
  const [isRecording, setIsRecording] = useState(false)
  const [liveTranscription, setLiveTranscription] = useState('')
  const [aiAnalysisResults, setAiAnalysisResults] = useState(null)

  // Custom Progress Notes States
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedAppointment, setSelectedAppointment] = useState('')
  const [selectedTemplate, setSelectedTemplate] = useState(isSoapSpecialty ? 'Default SOAP Template' : 'Clinical Progress Notes')
  const [noteText, setNoteText] = useState('')
  const [selectedHistoryNoteId, setSelectedHistoryNoteId] = useState(null)
  const [lastSavedTime, setLastSavedTime] = useState('')
  const [isAutoSaving, setIsAutoSaving] = useState(false)

  // Format YYYY-MM-DD date to "Apr 26, 2024" format
  const formatDateString = (dateStr) => {
    if (!dateStr) return ''
    if (dateStr.includes('-')) {
      const date = new Date(dateStr)
      if (!isNaN(date.getTime())) {
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      }
    }
    return dateStr
  }

  // Get note date display based on selected appointment
  const getNoteDateDisplay = () => {
    if (selectedAppointment && selectedAppointment.includes(' - ')) {
      return selectedAppointment.split(' - ')[0]
    }
    return new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  }

  // Get combined history (real + mock) for a patient
  const getPatientNotesHistory = (patientId) => {
    const realNotes = store.consultations
      .filter(c => c.patientId === patientId)
      .map(c => ({
        id: c.id,
        date: formatDateString(c.date),
        title: c.notes || (c.soap ? 'SOAP Note' : 'Clinical Note'),
        status: c.status === 'Completed' ? 'Final' : c.status,
        content: c.notes || (c.soap ? `S: ${c.soap.subjective}\n\nO: ${c.soap.objective}\n\nA: ${c.soap.assessment}\n\nP: ${c.soap.plan}` : '')
      }))

    const mockNotes = {
      'p1': [
        { id: 'mock_h1', date: 'Apr 24, 2024', title: 'SOAP Note', status: 'Draft', content: 'S: Patient reports mild lower back soreness after doing lumbar flexion movements. Rating pain at 4/10.\n\nO: Active lumbar flexion is limited to 60 degrees. Tenderness noted over L4-L5 vertebrae.\n\nA: Muscular strain overlaying mild chronic discogenic low back pain. Condition stable.\n\nP: Prescribed home core stabilizer workouts. Follow up scheduled next week.' },
        { id: 'mock_h2', date: 'Apr 18, 2024', title: 'Discharge Summary', status: 'Final', content: 'Reason for Treatment: Lower back pain rehabilitation.\n\nSummary of Treatment: Completed 6 sessions of physiotherapy and core stability training.\n\nCondition at Discharge: Patient reports zero back pain and 100% recovery of flexion range.\n\nDischarge Plan: Discharge to home exercise plan. No follow-up scheduled.' },
        { id: 'mock_h3', date: 'Apr 10, 2024', title: 'SOAP Note', status: 'Final', content: 'S: Mild back tightness. O: Tenderness noted over L4-L5 vertebrae. A: Discogenic pain. P: Soft tissue massage and stability exercises.' },
        { id: 'mock_h4', date: 'Mar 28, 2024', title: 'H&P', status: 'Final', content: 'History & Physical: Patient presents with history of chronic lower back pain. Assessment indicates range of motion is normal with minor discomfort.' }
      ],
      'p2': [
        { id: 'mock_h5', date: 'Apr 20, 2024', title: 'SOAP Note', status: 'Draft', content: 'S: Child is cooperative. Articulation is improving. O: Named 8/10 sibilants correctly. A: Improving language skills. P: Tongue worksheets.' },
        { id: 'mock_h6', date: 'Apr 02, 2024', title: 'Clinical Assessment', status: 'Final', content: 'Speech evaluation. Articulation errors noted on sibilants. Recommendation is 2x weekly therapy.' }
      ],
      'p3': [
        { id: 'mock_h7', date: 'Apr 14, 2024', title: 'SOAP Note', status: 'Final', content: 'S: Post-stroke left arm tightness. O: Range of motion flex is limited to 45 deg. A: Shoulder stiffness. P: Stretching exercises.' }
      ]
    }

    return [...realNotes, ...(mockNotes[patientId] || [])]
  }

  // Get display patient ID (e.g. p1 -> 88412)
  const getPatientDisplayId = (id) => {
    if (id === 'p1') return '88412'
    if (id === 'p2') return '88413'
    if (id === 'p3') return '88414'
    return id ? id.replace(/[a-zA-Z]/g, '88') : '88415'
  }

  // Get list of appointments for a patient
  const getPatientAppointments = (patientId) => {
    const list = store.appointments
      .filter(a => a.patientId === patientId)
      .map(a => `${formatDateString(a.date)} - ${a.time} (${a.appointmentType || 'Follow-up'})`)
    
    if (list.length === 0) {
      const todayStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
      return [`${todayStr} - 10:00 AM (Follow-up)`]
    }
    return list
  }

  // Insert formatting at textarea cursor
  const insertAtCursor = (beforeVal, afterVal) => {
    const textarea = document.getElementById('progress-note-editor')
    if (!textarea) return
    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const text = textarea.value
    const selectedText = text.substring(start, end)
    const replacement = beforeVal + selectedText + afterVal
    setNoteText(text.substring(0, start) + replacement + text.substring(end))
    
    setTimeout(() => {
      textarea.focus()
      textarea.setSelectionRange(start + beforeVal.length, start + beforeVal.length + selectedText.length)
    }, 0)
  }

  // Copy previous final note
  const handleCopyPrevious = () => {
    const history = getPatientNotesHistory(selectedPatientId)
    const previousFinal = history.find(n => n.status === 'Final')
    if (previousFinal) {
      setNoteText(previousFinal.content)
      toast.success('Copied previous final note content!')
    } else {
      toast.error('No previous final note found for this patient.')
    }
  }

  // Copy selected history note
  const handleCopySelected = () => {
    const history = getPatientNotesHistory(selectedPatientId)
    const selectedNote = history.find(n => n.id === selectedHistoryNoteId)
    if (selectedNote) {
      setNoteText(selectedNote.content)
      toast.success('Copied selected note content!')
    } else {
      toast.error('Please select a note from the history log first.')
    }
  }

  // Get selected appointment object helper
  const getSelectedAppointmentObj = () => {
    if (!selectedAppointment) return null
    return store.appointments.find(a => {
      const matchStr = `${formatDateString(a.date)} - ${a.time} (${a.appointmentType || 'Follow-up'})`
      return matchStr === selectedAppointment && a.patientId === selectedPatientId
    })
  }

  // Save as Draft
  const handleSaveDraft = () => {
    const apptObj = getSelectedAppointmentObj()
    const existingNoteObj = apptObj ? store.consultations.find(c => c.appointmentId === apptObj.id) : null

    if (existingNoteObj) {
      store.updateConsultation(existingNoteObj.id, {
        notes: noteText,
        status: 'Draft',
        date: new Date().toISOString().split('T')[0]
      })
      toast.success(`Progress note draft updated for ${patient.name}!`)
    } else {
      const newCons = {
        patientId: selectedPatientId,
        patientName: patient.name,
        notes: noteText,
        status: 'Draft',
        practitionerName: store.userRole === 'clinic' ? 'Clinic Manager' : 'Dr. Sarah Jenkins',
        profession: activeSpecialty,
        appointmentId: apptObj ? apptObj.id : undefined
      }
      store.addConsultation(newCons)
      toast.success(`Progress note draft saved for ${patient.name}!`)
    }
  }

  // Save as Final
  const handleSaveFinal = () => {
    const apptObj = getSelectedAppointmentObj()
    const existingNoteObj = apptObj ? store.consultations.find(c => c.appointmentId === apptObj.id) : null

    if (existingNoteObj) {
      store.updateConsultation(existingNoteObj.id, {
        notes: noteText,
        status: 'Completed',
        date: new Date().toISOString().split('T')[0]
      })
      toast.success(`Progress note saved as final for ${patient.name}!`)
    } else {
      const newCons = {
        patientId: selectedPatientId,
        patientName: patient.name,
        notes: noteText,
        status: 'Completed',
        practitionerName: store.userRole === 'clinic' ? 'Clinic Manager' : 'Dr. Sarah Jenkins',
        profession: activeSpecialty,
        appointmentId: apptObj ? apptObj.id : undefined
      }
      store.addConsultation(newCons)
      toast.success(`Progress note saved as final for ${patient.name}!`)
    }
  }

  // Sync URL parameters on mount or when search changes
  useEffect(() => {
    const params = new URLSearchParams(location.search)
    const pId = params.get('patientId')
    const apptId = params.get('appointmentId')
    
    if (pId) {
      setSelectedPatientId(pId)
    }
    
    if (apptId) {
      const apptObj = store.appointments.find(a => a.id === apptId)
      if (apptObj) {
        const matchStr = `${formatDateString(apptObj.date)} - ${apptObj.time} (${apptObj.appointmentType || 'Follow-up'})`
        setSelectedAppointment(matchStr)
      }
      
      const existingNoteObj = store.consultations.find(c => c.appointmentId === apptId)
      if (existingNoteObj) {
        setNoteText(existingNoteObj.notes || '')
      }
    }
  }, [location.search, store.appointments, store.consultations])

  // Sync template selection when simulated specialty changes
  useEffect(() => {
    const isSoap = activeSpecialty !== 'Speech Pathologist' && activeSpecialty !== 'Speech Therapist' && activeSpecialty !== 'Occupational Therapist'
    setSelectedTemplate(isSoap ? 'Default SOAP Template' : 'Clinical Progress Notes')
  }, [activeSpecialty])

  // Sync templates on template change or selected patient change
  useEffect(() => {
    // If we loaded an existing note from URL, do not overwrite it with template content
    const params = new URLSearchParams(location.search)
    const apptId = params.get('appointmentId')
    if (apptId) {
      const existingNoteObj = store.consultations.find(c => c.appointmentId === apptId)
      if (existingNoteObj) {
        return // Bypass template loading
      }
    }

    let text = ''
    if (selectedTemplate === 'Default SOAP Template') {
      text = `S: Patient presents for follow-up regarding chronic back pain, reporting moderate improvement.\n\nO: Physical exam reveals tenderness in the L5-S1 region.\n\nA: Chronic lower back pain, improving.\n\nP: Continue physical therapy, adjust medication, schedule 4-week follow-up.`
    } else if (selectedTemplate === 'Clinical Progress Notes') {
      text = `Subject/Issues: Patient presents for session, reports positive engagement and progress in activities.\n\nObservations: Participates actively in therapeutic exercises. Demonstrates cooperative communication and focus.\n\nIntervention: Applied tailored clinical strategies and exercises to support developmental goals.\n\nPlan: Continue regular treatment schedule and monitor progress.`
    } else if (selectedTemplate === 'Initial Assessment') {
      text = `Chief Complaint: Patient reports lower back soreness and stiffness.\nHistory of Present Illness: Discomfort started 3 weeks ago after lifting a heavy box.\nPhysical Exam: Active flexion limited to 60 degrees. Tenderness noted.\nAssessment & Plan: Stable lumbar strain. Recommend stretching exercises twice daily.`
    } else if (selectedTemplate === 'Discharge Summary') {
      text = `Reason for Treatment: Lower back pain rehabilitation.\nSummary of Treatment: Completed 6 sessions of physiotherapy and core stability training.\nCondition at Discharge: Patient reports zero back pain and 100% recovery of flexion range.\nDischarge Plan: Discharge to home exercise plan. No follow-up scheduled.`
    } else if (selectedTemplate === 'History and Physical (H&P)') {
      text = `History & Physical:\nSubjective: Patient reports general wellness, minor neck tightness.\nObjective Vitals: BP 120/80, Heart Rate 72 bpm.\nAssessment: Postural strain from desk work.\nPlan: Ergonomic advice and daily neck stretching.`
    } else if (selectedTemplate === 'Functional Capacity Assessment') {
      text = `Functional Capacity Assessment:\nADLs: Independent in basic self-care, requires assistance for complex tasks.\nSensory Profile: Moderate sensitivity to auditory stimuli.\nMobility: Steady gait, minor balance fatigue.\nRecommendations: Sensory modifications at school/work, follow up in 3 months.`
    }
    setNoteText(text)
  }, [selectedTemplate, selectedPatientId])

  // Sync default appointment when patient changes
  useEffect(() => {
    // If there is an appointmentId in URL, we want to keep it selected instead of defaulting
    const params = new URLSearchParams(location.search)
    if (params.get('appointmentId')) return

    const appts = getPatientAppointments(selectedPatientId)
    if (appts && appts.length > 0) {
      setSelectedAppointment(appts[0])
    }
    setSelectedHistoryNoteId(null)
  }, [selectedPatientId, location.search])

  // Auto-save simulator timer
  useEffect(() => {
    if (!noteText) return
    setIsAutoSaving(true)
    const timeout = setTimeout(() => {
      const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true })
      setLastSavedTime(time)
      setIsAutoSaving(false)
    }, 2000)

    return () => clearTimeout(timeout)
  }, [noteText])

  // Load the selected patient
  const patient = store.patients.find(p => p.id === selectedPatientId) || store.patients[0]

  useEffect(() => {
    if (patient) {
      soapForm.resetFields()
      soapForm.setFieldsValue({
        subjective: patient.id === 'p1' ? 'Patient reports mild lower back soreness after doing lumbar flexion movements. Rating pain at 4/10.' : '',
        objective: patient.id === 'p1' ? 'Active lumbar flexion is limited to 60 degrees. Tenderness noted over L4-L5 vertebrae.' : '',
        assessment: patient.id === 'p1' ? 'Muscular strain overlaying mild chronic discogenic low back pain. Condition stable.' : '',
        plan: patient.id === 'p1' ? 'Prescribed home core stabilizer workouts. Follow up scheduled next week.' : ''
      })
    }
  }, [selectedPatientId, patient, soapForm])

  if (!patient) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-bold text-slate-800 dark:text-white">No patients found in directory.</h3>
      </div>
    )
  }

  // Calculate age from DOB
  const calculateAge = (dobString) => {
    if (!dobString) return 'N/A'
    const today = new Date()
    const birthDate = new Date(dobString)
    let age = today.getFullYear() - birthDate.getFullYear()
    const m = today.getMonth() - birthDate.getMonth()
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }
    return age
  }

  // Simulation handlers
  const toggleRecording = () => {
    if (isRecording) {
      setIsRecording(false)
      // Synthesize values depending on the specialty
      let generatedText = ""
      if (activeSpecialty === 'Physiotherapist') {
        generatedText = "Patient John Miller presents with low back tightness. Passive straight leg raise is 75 degrees on the right, 60 on the left. Lumbar extension reproduces localized L4 discomfort. Assessed as lower lumbar disc stress. Prescribed bird-dogs and pelvic tilts. Re-evaluating next Monday."
      } else if (activeSpecialty === 'Psychologist') {
        generatedText = "Client reports persistent social anxiety symptoms in work settings. Expresses high anxiety rating of 7/10. Cognitive restructuring drills applied. Recommended deep diaphragmatic breathing and cognitive reframing."
      } else if (activeSpecialty === 'Speech Pathologist') {
        generatedText = "Child completed articulation drills naming 10 items. Scored 80% accuracy on sibilants. Assigned tongue elevation worksheet."
      } else {
        generatedText = "Consultation completed. Patient shows positive response to active therapeutic movements. Prescribed follow-up rehabilitation exercises."
      }
      setLiveTranscription(generatedText)
      toast.success('Dictation transcribed successfully!')
    } else {
      setIsRecording(true)
      setLiveTranscription('Recording...')
      setAiAnalysisResults(null)
    }
  }

  const handleAddTranscriptionToNote = () => {
    if (!liveTranscription || liveTranscription === 'Recording...') {
      toast.error('No transcription available to add.')
      return
    }
    setNoteText(prev => {
      const spacing = prev.trim() ? '\n\n' : ''
      return prev + spacing + liveTranscription
    })
    toast.success('Transcription added to progress note!')
    setLiveTranscription('')
  }

  const handleGenerateAINotes = () => {
    if (!liveTranscription || liveTranscription === 'Recording...') {
      toast.error('Please record/dictate some text first.')
      return
    }
    toast.loading('AI is structuring notes...', { duration: 1000 })
    setTimeout(() => {
      if (isSoapSpecialty) {
        // Structure transcription into SOAP format
        let soapData = {}
        if (activeSpecialty === 'Physiotherapist') {
          soapData = {
            subjective: 'Patient reports lower back stiffness. Reports discomfort during sitting prolonged periods.',
            objective: 'Passive straight leg raise (SLR): 75° right, 60° left. Discomfort on L4 spine extension.',
            assessment: 'Lower lumbar vertebral disc load stress with associated musculature spasms.',
            plan: 'Assigned Bird-Dogs and pelvic tilt stability drills. Follow-up consultation in 7 days.'
          }
        } else {
          soapData = {
            subjective: 'Client presents with symptoms related to ' + activeSpecialty + ' rehabilitation.',
            objective: 'Clinical assessments indicate moderate restrictions/difficulties in functional exercises.',
            assessment: 'Rehabilitation progressing. Client displays cooperative motor/cognitive focus.',
            plan: 'Assigned home program. Re-evaluate in next consultation.'
          }
        }
        soapForm.setFieldsValue(soapData)
        setAiAnalysisResults('SOAP Note Synthesized')
        toast.success('AI Notes compiled into SOAP form!')
      } else {
        // Non-SOAP structure compiled directly into text notes
        let generatedNote = ""
        if (activeSpecialty === 'Speech Pathologist' || activeSpecialty === 'Speech Therapist') {
          generatedNote = `Subject/Issues: Child completed articulation drills for speech clarity.\n\nObservations: Articulation accuracy was 80% on target sibilants. Child was engaged and followed instructions.\n\nIntervention: Directed articulation exercises and tongue elevation practice.\n\nPlan: Assigned tongue elevation worksheet for home practice. Re-evaluate in 2 weeks.`
        } else if (activeSpecialty === 'Occupational Therapist') {
          generatedNote = `Subject/Issues: Client assessed for daily living independence and sensory needs.\n\nObservations: Needs moderate support for fine motor transitions. Sensory sensitivity to loud background noises noted.\n\nIntervention: Practiced sensory adaptation techniques and manual dexterity tasks.\n\nPlan: Advised sensory breaks at school. Review functional progress next month.`
        } else {
          generatedNote = `Subject/Issues: Client participated in general rehabilitation program.\n\nObservations: Client displays positive motivation and stable execution of exercises.\n\nIntervention: Guided client through targeted functional movements.\n\nPlan: Continue current program and review in subsequent session.`
        }
        setNoteText(generatedNote)
        toast.success('AI Notes compiled and loaded into progress notes!')
      }
    }, 1000)
  }

  const handleGenerateAIReport = () => {
    toast.loading('AI is drafting clinical report...', { duration: 1200 })
    setTimeout(() => {
      toast.success('Report Draft generated! Saved in Drafts folder.')
      navigate('/clinic/notes-reports?tab=reports')
    }, 1200)
  }

  const handleSaveSOAP = (values) => {
    const formatted = {
      patientId: patient.id,
      patientName: patient.name,
      soap: values,
      status: 'Completed',
      practitionerName: 'Dr. Sarah Jenkins',
      profession: activeSpecialty
    }
    store.addConsultation(formatted)
    toast.success('Clinical SOAP note saved successfully!')
  }

  // Prescribe exercises handler
  const handlePrescribeExercises = (values) => {
    const prog = {
      patientId: patient.id,
      patientName: patient.name,
      programName: values.programName || 'Home Recovery Program',
      practitionerName: 'Dr. Sarah Jenkins',
      exercises: [
        { videoName: values.exVideo1, instructions: values.inst1, sets: values.sets1 || 3, reps: values.reps1 || 10, frequency: values.freq1 || 'Daily' }
      ]
    }
    store.addPrescribedExercise(prog)
    toast.success(`Exercises assigned to ${patient.name} via Patient Portal!`)
    exerciseForm.resetFields()
  }

  // AI Referral Letter generation
  const handleDraftReferralLetter = () => {
    const values = referralForm.getFieldsValue()
    if (!values.recipient) {
      toast.error('Please select referral recipient first.')
      return
    }
    toast.loading('AI is drafting referral letter...', { duration: 1000 })
    setTimeout(() => {
      const draft = `Dear ${values.recipient},\n\nI am writing to refer my patient, ${patient.name} (${calculateAge(patient.dob)}yo), for diagnostic review and co-management regarding their condition (${patient.diagnosis ? patient.diagnosis.join(', ') : 'Injury'}).\n\nClinical notes: Patient presents with musculoskeletal symptoms under our treating clinical workspace. I appreciate your expert review.\n\nSincerely,\nDr. Sarah Jenkins\nSpecialist in ${activeSpecialty}`
      referralForm.setFieldsValue({ letter: draft })
      toast.success('AI referral letter drafted! Please review and approve.')
    }, 1000)
  }

  const handleSendReferral = (values) => {
    const formatted = {
      patientId: patient.id,
      patientName: patient.name,
      recipient: values.recipient,
      recipientType: values.recipientType || 'Specialist',
      letter: values.letter,
      status: 'Sent'
    }
    store.addReferral(formatted)
    toast.success(`Referral letter successfully sent to ${values.recipient}!`)
    referralForm.resetFields()
  }

  // Invoicing handler
  const handleCreateInvoice = (values) => {
    // Generate invoice in store
    const item = store.services.find(s => s.name === values.serviceName) || store.services[0]
    const price = item ? item.price : 120
    const claim = values.fundingType || 'Private'
    
    // Add invoice to store
    const newInv = {
      id: `INV-${Date.now().toString().slice(-4)}`,
      clientName: patient.name,
      patientId: patient.id,
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      amount: price,
      due: price,
      status: 'Sent',
      serviceType: item.name
    }
    // Append to invoices array in store
    store.invoices = [newInv, ...store.invoices]
    
    toast.success(`Invoice ${newInv.id} issued under ${claim} funding!`)
    invoiceForm.resetFields()
  }

  // Dynamically load templates & details based on active simulated profession
  const renderProfessionSpecificFields = () => {
    switch (activeSpecialty) {
      case 'Physiotherapist':
      case 'Chiropractor':
      case 'Osteopath':
        return (
          <div className="p-4 bg-blue-50/50 dark:bg-slate-950/40 border border-blue-100 dark:border-slate-800 rounded-2xl space-y-4">
            <h5 className="font-extrabold text-xs text-blue-500 uppercase tracking-wider">Joint Mobilisation & Spine Alignment Checks</h5>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="rangeOfMotion" label={<span className="text-[11px] font-bold text-slate-500">Active ROM limitation</span>}>
                <Input placeholder="e.g. Lumbar Flexion 60 deg, Extension limited" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="spinePalpation" label={<span className="text-[11px] font-bold text-slate-500">Palpation Tenderness / Spine alignment</span>}>
                <Input placeholder="e.g. Local L4-L5 vertebrae tenderness" className="rounded-xl" />
              </Form.Item>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <Form.Item name="muscleStrength" label={<span className="text-[11px] font-bold text-slate-500">Muscle Testing (0-5)</span>}>
                <Input placeholder="e.g. Left quad 4/5" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="outcomeMeasure" label={<span className="text-[11px] font-bold text-slate-500">Outcome Measure Score</span>}>
                <Input placeholder="e.g. Oswestry Back Pain: 32%" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="postureDetails" label={<span className="text-[11px] font-bold text-slate-500">Postural alignment details</span>}>
                <Input placeholder="e.g. Forward head, elevated R shoulder" className="rounded-xl" />
              </Form.Item>
            </div>
          </div>
        )
      case 'Occupational Therapist':
        return (
          <div className="p-4 bg-purple-50/50 dark:bg-slate-950/40 border border-purple-100 dark:border-slate-800 rounded-2xl space-y-4">
            <h5 className="font-extrabold text-xs text-purple-600 uppercase tracking-wider">Functional Capacity Assessment (NDIS Focus)</h5>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="adlRestricted" label={<span className="text-[11px] font-bold text-slate-500">Activities of Daily Living (ADLs) Restrictions</span>}>
                <Input placeholder="e.g. Needs physical assistance for shower & dressing" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="assistiveTech" label={<span className="text-[11px] font-bold text-slate-500">Recommended Assistive Technology</span>}>
                <Input placeholder="e.g. Over-toilet frame, shower chair, front rails" className="rounded-xl" />
              </Form.Item>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="homeModifications" label={<span className="text-[11px] font-bold text-slate-500">Home Modifications Required</span>}>
                <Input placeholder="e.g. Ramp installation for front entrance" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="cognitiveSkill" label={<span className="text-[11px] font-bold text-slate-500">Cognitive & Focus parameters</span>}>
                <Input placeholder="e.g. High focus during guided tasks, easily distracted" className="rounded-xl" />
              </Form.Item>
            </div>
          </div>
        )
      case 'Psychologist':
        return (
          <div className="p-4 bg-amber-50/50 dark:bg-slate-950/40 border border-amber-100 dark:border-slate-800 rounded-2xl space-y-4">
            <h5 className="font-extrabold text-xs text-amber-600 uppercase tracking-wider">Mental Health Indicators & Cognitive Parameters</h5>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="moodAffect" label={<span className="text-[11px] font-bold text-slate-500">Mood and Affect</span>}>
                <Input placeholder="e.g. Anxious mood, flat affect" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="anxietyRating" label={<span className="text-[11px] font-bold text-slate-500">Anxiety Rating (0-10)</span>}>
                <Input placeholder="e.g. 7 out of 10" className="rounded-xl" />
              </Form.Item>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="cognitiveDistortions" label={<span className="text-[11px] font-bold text-slate-500">Observed Cognitive Distortions</span>}>
                <Input placeholder="e.g. Catastrophizing, all-or-nothing thinking" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="copingMechanisms" label={<span className="text-[11px] font-bold text-slate-500">Coping Strategies discussed</span>}>
                <Input placeholder="e.g. Cognitive restructuring, square breathing" className="rounded-xl" />
              </Form.Item>
            </div>
          </div>
        )
      case 'Speech Pathologist':
        return (
          <div className="p-4 bg-emerald-50/50 dark:bg-slate-950/40 border border-emerald-100 dark:border-slate-800 rounded-2xl space-y-4">
            <h5 className="font-extrabold text-xs text-emerald-600 uppercase tracking-wider">Speech & Language Scoring Logs</h5>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="articulationScore" label={<span className="text-[11px] font-bold text-slate-500">Articulation Card accuracy</span>}>
                <Input placeholder="e.g. Named 8/10 items, difficulty with sibilants" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="swallowingSafety" label={<span className="text-[11px] font-bold text-slate-500">Dysphagia / Swallowing assessment</span>}>
                <Input placeholder="e.g. Clean swallow test with thin liquids" className="rounded-xl" />
              </Form.Item>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="receptiveLanguage" label={<span className="text-[11px] font-bold text-slate-500">Receptive Language scoring</span>}>
                <Input placeholder="e.g. Followed 3-step directions with minimal prompts" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="aacDevice" label={<span className="text-[11px] font-bold text-slate-500">AAC Device training logs</span>}>
                <Input placeholder="e.g. Used screen-select to indicate basic needs" className="rounded-xl" />
              </Form.Item>
            </div>
          </div>
        )
      case 'Exercise Physiologist':
        return (
          <div className="p-4 bg-teal-50/50 dark:bg-slate-950/40 border border-teal-100 dark:border-slate-800 rounded-2xl space-y-4">
            <h5 className="font-extrabold text-xs text-teal-600 uppercase tracking-wider">Cardiac & Rehabilitation Parameters</h5>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="restingHeartRate" label={<span className="text-[11px] font-bold text-slate-500">Resting Heart Rate / BP</span>}>
                <Input placeholder="e.g. 72 bpm, BP 120/80" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="rpeTesting" label={<span className="text-[11px] font-bold text-slate-500">RPE (Borg Scale 6-20) during loads</span>}>
                <Input placeholder="e.g. RPE 13 (somewhat hard) at 60W load" className="rounded-xl" />
              </Form.Item>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Form.Item name="aerobicCapacity" label={<span className="text-[11px] font-bold text-slate-500">Aerobic Workout limitations</span>}>
                <Input placeholder="e.g. Fatigue onset after 10 mins treadmill walking" className="rounded-xl" />
              </Form.Item>
              <Form.Item name="resistiveLoads" label={<span className="text-[11px] font-bold text-slate-500">Active Resistance Loads applied</span>}>
                <Input placeholder="e.g. Leg press 40kg, chest press 15kg" className="rounded-xl" />
              </Form.Item>
            </div>
          </div>
        )
      default:
        return (
          <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 rounded-2xl">
            <h5 className="font-extrabold text-xs text-slate-600 uppercase tracking-wider">General Health physical assessment</h5>
            <div className="grid grid-cols-2 gap-4 mt-3">
              <Form.Item name="clinicalSymptoms" label={<span className="text-[11px] font-bold text-slate-500">Chief complaints / symptoms</span>}>
                <Input placeholder="Enter details..." className="rounded-xl" />
              </Form.Item>
              <Form.Item name="clinicalVitals" label={<span className="text-[11px] font-bold text-slate-500">Vitals check</span>}>
                <Input placeholder="e.g. Temperature, BP, heart rate" className="rounded-xl" />
              </Form.Item>
            </div>
          </div>
        )
    }
  }

  const apptObjForLock = getSelectedAppointmentObj()
  const existingNoteForLock = apptObjForLock ? store.consultations.find(c => c.appointmentId === apptObjForLock.id) : null
  const isNoteFinal = existingNoteForLock && existingNoteForLock.status === 'Completed'

  return (
    <div className="space-y-6 font-sans">
      {/* ── Patient Context Header ── */}
      <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-850 p-6 rounded-2xl shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center text-white bg-[#8C4BFF] font-bold text-base select-none">
              {patient.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold text-slate-850 dark:text-white m-0">{patient.name}</h2>
                <Tag color="cyan" className="m-0 border-none font-bold text-[8.5px] uppercase rounded-full px-2.5 py-0.5">{patient.tags?.join(' & ') || 'NDIS'}</Tag>
              </div>
              <p className="text-slate-400 text-[11px] font-semibold mt-1">
                Age: {calculateAge(patient.dob)}yo &bull; DOB: {patient.dob} &bull; Diagnosis: {patient.diagnosis ? patient.diagnosis.join(', ') : 'Injury'}
              </p>
            </div>
          </div>

          {/* Patient Switcher Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Treating Patient:</span>
            <Select 
              value={selectedPatientId}
              onChange={setSelectedPatientId}
              style={{ width: 200, height: 38 }}
              className="font-bold border-slate-200"
            >
              {store.patients.map(p => (
                <Option key={p.id} value={p.id}>{p.name}</Option>
              ))}
            </Select>
          </div>
        </div>

        {patient.alerts && (
          <Alert 
            message={<span className="font-extrabold text-red-550 text-xs">Patient Safety Alert:</span>}
            description={<span className="text-slate-500 font-semibold text-xs">{patient.alerts}</span>}
            type="error"
            showIcon
            icon={<ExclamationCircleOutlined className="text-red-500" />}
            className="rounded-xl border-red-100 bg-red-50/20"
          />
        )}
      </div>

      {/* ── Tabs Workspace Ecosystem ── */}
      <Card className="border border-slate-150 dark:border-slate-850 dark:bg-slate-900 rounded-2xl shadow-sm overflow-hidden select-none">
        <Tabs activeKey={activeTab} onChange={setActiveTab} type="card" className="p-1.5 rounded-2xl bg-slate-50/50 dark:bg-slate-950/20">
          
          {/* TAB 1: SOAP & CLINICAL NOTES FORM */}
          <Tabs.TabPane tab={<span><FileTextOutlined /> {isSoapSpecialty ? 'SOAP & Clinical Notes' : 'Clinical Progress Notes'}</span>} key="notes">
            <div className="grid grid-cols-1 lg:grid-cols-4 border border-slate-150 dark:border-slate-850 rounded-2xl overflow-hidden min-h-[650px] bg-slate-50 dark:bg-slate-950/20">
              
              {/* Left sub-sidebar (25% width: col-span-1) */}
              <div className={`lg:col-span-1 p-4 border-r flex flex-col justify-between space-y-4 select-none transition-colors duration-300 ${
                darkMode 
                  ? 'bg-slate-950 border-slate-850 text-white' 
                  : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}>
                <div className="space-y-4">
                  {/* Patient Search */}
                  <div>
                    <span className={`text-[10px] uppercase font-extrabold tracking-wider block mb-1.5 ${
                      darkMode ? 'text-slate-400' : 'text-slate-500'
                    }`}>Patient Search</span>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <SearchOutlined style={{ color: darkMode ? '#94a3b8' : '#64748b' }} />
                      </span>
                      <input 
                        type="text"
                        placeholder="Search for patients..." 
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        className={`w-full h-10 pl-9 pr-4 rounded-xl text-xs focus:outline-none transition-all ${
                          darkMode 
                            ? 'placeholder-slate-400' 
                            : 'placeholder-slate-400'
                        }`}
                        style={{ 
                          backgroundColor: darkMode ? '#1e293b' : '#ffffff', 
                          border: darkMode ? '1px solid #334155' : '1px solid #cbd5e1', 
                          color: darkMode ? '#ffffff' : '#1e293b'
                        }}
                      />
                    </div>
                  </div>

                  {/* Patient Selector List */}
                  <div>
                    <span className={`text-[10px] uppercase font-extrabold tracking-wider block mb-1.5 ${
                      darkMode ? 'text-slate-400' : 'text-slate-500'
                    }`}>Patient Selector</span>
                    <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                      {store.patients
                        .filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
                        .map(p => {
                          const isSelected = p.id === selectedPatientId
                          return (
                            <div 
                              key={p.id}
                              onClick={() => setSelectedPatientId(p.id)}
                              className={`p-2 rounded-xl flex items-center gap-2 cursor-pointer transition-all ${
                                isSelected 
                                  ? 'bg-[#8C4BFF] shadow text-white font-bold' 
                                  : darkMode 
                                    ? 'bg-slate-800 hover:bg-slate-750 text-slate-350' 
                                    : 'bg-white hover:bg-slate-100 border border-slate-200/60 text-slate-700 shadow-sm'
                              }`}
                            >
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                                isSelected ? 'bg-white text-[#8C4BFF]' : 'bg-[#8C4BFF] text-white'
                              }`}>
                                {p.name.charAt(0)}
                              </div>
                              <div className="flex-1 min-w-0">
                                <span className="text-xs block truncate leading-none font-bold" style={{ color: isSelected ? '#ffffff' : darkMode ? '#ffffff' : '#1e293b' }}>{p.name}</span>
                                <span className="text-[9px] block mt-1.5 leading-none" style={{ color: isSelected ? '#f3e8ff' : darkMode ? '#cbd5e1' : '#64748b' }}>DOB: {formatDateString(p.dob)}</span>
                                <span className="text-[9px] block mt-1 leading-none" style={{ color: isSelected ? '#f3e8ff' : darkMode ? '#cbd5e1' : '#64748b' }}>ID: {getPatientDisplayId(p.id)}</span>
                              </div>
                            </div>
                          )
                        })
                      }
                    </div>
                  </div>

                  {/* Appointment Selector */}
                  <div>
                    <span className={`text-[10px] uppercase font-extrabold tracking-wider block mb-1.5 ${
                      darkMode ? 'text-slate-400' : 'text-slate-500'
                    }`}>Appointment Selector</span>
                    <Select 
                      value={selectedAppointment}
                      onChange={setSelectedAppointment}
                      className="w-full rounded-xl"
                      style={{ width: '100%' }}
                    >
                      {getPatientAppointments(selectedPatientId).map((appt, idx) => (
                        <Option key={idx} value={appt}>{appt}</Option>
                      ))}
                    </Select>
                  </div>

                  {/* Clinical Note Templates */}
                  <div>
                    <span className={`text-[10px] uppercase font-extrabold tracking-wider block mb-1.5 ${
                      darkMode ? 'text-slate-400' : 'text-slate-500'
                    }`}>Clinical Note Templates</span>
                    <Select 
                      value={selectedTemplate}
                      onChange={setSelectedTemplate}
                      className="w-full rounded-xl"
                      style={{ width: '100%' }}
                    >
                      {isSoapSpecialty ? (
                        <>
                          <Option value="Default SOAP Template">Default SOAP Template</Option>
                          <Option value="Initial Assessment">Initial Assessment Template</Option>
                          <Option value="Discharge Summary">Discharge Summary Template</Option>
                          <Option value="History and Physical (H&P)">History & Physical (H&P)</Option>
                        </>
                      ) : (
                        <>
                          <Option value="Clinical Progress Notes">Clinical Progress Notes</Option>
                          <Option value="Initial Assessment">Initial Assessment Template</Option>
                          <Option value="Discharge Summary">Discharge Summary Template</Option>
                          <Option value="Functional Capacity Assessment">Functional Capacity Assessment</Option>
                        </>
                      )}
                    </Select>
                  </div>

                  {/* Copy Actions */}
                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <Button 
                      onClick={handleCopyPrevious}
                      icon={<CopyOutlined />}
                      size="small"
                      style={{
                        backgroundColor: darkMode ? '#1e293b' : '#f1f5f9',
                        color: darkMode ? '#ffffff' : '#1e293b',
                        borderColor: darkMode ? '#475569' : '#cbd5e1'
                      }}
                      className={`rounded-lg text-[10px] font-bold w-full ${
                        darkMode ? 'hover:bg-slate-800' : 'hover:bg-slate-200'
                      }`}
                    >
                      Copy Previous
                    </Button>
                    <Button 
                      onClick={handleCopySelected}
                      icon={<CopyOutlined />}
                      disabled={!selectedHistoryNoteId}
                      size="small"
                      style={{
                        backgroundColor: !selectedHistoryNoteId 
                          ? (darkMode ? '#0f172a' : '#f8fafc') 
                          : (darkMode ? '#1e293b' : '#f1f5f9'),
                        color: !selectedHistoryNoteId 
                          ? (darkMode ? '#475569' : '#94a3b8') 
                          : (darkMode ? '#ffffff' : '#1e293b'),
                        borderColor: !selectedHistoryNoteId 
                          ? (darkMode ? '#1e293b' : '#e2e8f0') 
                          : (darkMode ? '#475569' : '#cbd5e1'),
                        opacity: !selectedHistoryNoteId ? 0.5 : 1
                      }}
                      className={`rounded-lg text-[10px] font-bold w-full ${
                        darkMode ? 'hover:bg-slate-800' : 'hover:bg-slate-200'
                      }`}
                    >
                      Copy Selected
                    </Button>
                  </div>
                </div>

                {/* Note History List */}
                <div className={`pt-2 border-t ${darkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                  <span className={`text-[10px] uppercase font-extrabold tracking-wider block mb-1.5 ${
                    darkMode ? 'text-slate-400' : 'text-slate-500'
                  }`}>Patient Note History</span>
                  <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                    {getPatientNotesHistory(selectedPatientId).length === 0 ? (
                      <div className="text-[10px] text-slate-500 italic text-center py-2">No note history found.</div>
                    ) : (
                      getPatientNotesHistory(selectedPatientId).map((note, idx) => {
                        const isSelected = note.id === selectedHistoryNoteId
                        const isDraft = note.status === 'Draft'
                        return (
                          <div 
                            key={note.id || idx}
                            onClick={() => setSelectedHistoryNoteId(note.id)}
                            className={`p-2.5 rounded-xl border cursor-pointer transition-all text-[10px] ${
                              isSelected 
                                ? 'border-[#8C4BFF] bg-[#8C4BFF]/10 dark:bg-[#8C4BFF]/20' 
                                : darkMode 
                                  ? 'border-slate-800 bg-slate-800/50 hover:bg-slate-800 text-slate-300' 
                                  : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700 shadow-sm'
                            }`}
                          >
                            <div className="flex justify-between items-center mb-1.5">
                              <span className={`font-bold ${isSelected ? 'text-[#8C4BFF]' : darkMode ? 'text-slate-200' : 'text-slate-700'}`}>{note.date}</span>
                              <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase ${
                                isDraft ? 'bg-amber-500/20 text-amber-500' : 'bg-emerald-500/20 text-emerald-450'
                              }`}>
                                {note.status}
                              </span>
                            </div>
                            <span className={`block text-[9px] truncate font-semibold ${
                              isSelected ? 'text-[#8C4BFF]/80' : darkMode ? 'text-slate-400' : 'text-slate-550'
                            }`}>{note.title}</span>
                          </div>
                        )
                      })
                    )}
                  </div>
                </div>
              </div>

              {/* Right editor panel (75% width: col-span-3) */}
              <div className="lg:col-span-3 bg-white dark:bg-slate-900 p-6 flex flex-col justify-between space-y-4">
                
                {/* Header & Status Indicator */}
                <div className="flex justify-between items-center pb-3 border-b border-slate-150 dark:border-slate-850">
                  <div>
                    <h3 className="text-base font-black text-slate-800 dark:text-white m-0">
                      New Progress Note - {getNoteDateDisplay()}
                    </h3>
                    <div className="flex items-center gap-1.5 mt-1.5">
                      <CheckCircleFilled className="text-emerald-500 text-xs" />
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold">
                        {isAutoSaving ? 'Auto-saving draft...' : `Draft auto-saved at ${lastSavedTime || '10:15 AM'}`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Metadata Row */}
                <div className="bg-slate-50 dark:bg-slate-950/40 border border-slate-150 dark:border-slate-850 rounded-xl p-3.5 flex flex-wrap justify-between items-center text-xs gap-3">
                  <div>
                    <span className="font-bold text-slate-400 dark:text-slate-500">Patient:</span>{' '}
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">{patient.name}</span>
                    <span className="mx-2 text-slate-350">|</span>
                    <span className="font-bold text-slate-400 dark:text-slate-500">DOB:</span>{' '}
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">{formatDateString(patient.dob)}</span>
                    <span className="mx-2 text-slate-355">|</span>
                    <span className="font-bold text-slate-400 dark:text-slate-500">ID:</span>{' '}
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">{getPatientDisplayId(selectedPatientId)}</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-400 dark:text-slate-500">
                      {store.userRole === 'clinic' ? 'Admin:' : 'Doctor:'}
                    </span>{' '}
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">
                      {store.userRole === 'clinic' ? 'Clinic Manager' : 'Dr. Sarah Jenkins, MD'}
                    </span>
                    <span className="mx-2 text-slate-350">|</span>
                    <span className="font-bold text-slate-400 dark:text-slate-500">ID:</span>{' '}
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">
                      {store.userRole === 'clinic' ? 'A0912' : 'D0451'}
                    </span>
                  </div>
                </div>

                {/* Voice Dictation Assistant Widget */}
                <div className="bg-gradient-to-r from-[#8C4BFF]/5 to-[#30D2BE]/5 border border-slate-150 dark:border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-extrabold text-xs text-slate-700 dark:text-white flex items-center gap-2">
                      <AudioOutlined style={{ color: '#8C4BFF' }} /> Voice Dictation Assistant
                    </span>
                    {isRecording && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase bg-red-500/10 text-red-500">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" /> Recording
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <Button
                      onClick={toggleRecording}
                      type={isRecording ? "primary" : "default"}
                      danger={isRecording}
                      icon={<AudioOutlined />}
                      className="rounded-xl font-bold h-10 px-5 text-xs flex items-center gap-2"
                      style={!isRecording ? { borderColor: '#cbd5e1' } : {}}
                    >
                      {isRecording ? 'Stop & Transcribe' : 'Start Live Dictation'}
                    </Button>
                    
                    {isRecording && (
                      <div className="flex items-center gap-1">
                        <div className="w-1 bg-[#8C4BFF] h-6 rounded animate-pulse" style={{ animationDelay: '0.1s' }} />
                        <div className="w-1 bg-[#30D2BE] h-4 rounded animate-pulse" style={{ animationDelay: '0.2s' }} />
                        <div className="w-1 bg-[#8C4BFF] h-8 rounded animate-pulse" style={{ animationDelay: '0.3s' }} />
                        <div className="w-1 bg-[#30D2BE] h-5 rounded animate-pulse" style={{ animationDelay: '0.4s' }} />
                        <div className="w-1 bg-[#8C4BFF] h-3 rounded animate-pulse" style={{ animationDelay: '0.5s' }} />
                      </div>
                    )}
                    
                    {!isRecording && liveTranscription && liveTranscription !== 'Recording...' && (
                      <Button
                        onClick={handleAddTranscriptionToNote}
                        type="primary"
                        icon={<PlusOutlined />}
                        style={{ backgroundColor: '#10B981', borderColor: '#10B981' }}
                        className="rounded-xl font-bold h-10 px-5 text-xs text-white"
                      >
                        Add to Note
                      </Button>
                    )}
                  </div>

                  {liveTranscription && (
                    <div className="p-3 bg-slate-50 dark:bg-slate-955 border border-slate-150 dark:border-slate-800 rounded-xl">
                      <span className="text-[9px] uppercase font-black text-slate-400 block mb-1">Live Transcription Preview</span>
                      <p className="text-slate-650 dark:text-slate-350 italic m-0 text-xs leading-relaxed">
                        "{liveTranscription}"
                      </p>
                    </div>
                  )}
                </div>

                {/* Rich Formatting Toolbar */}
                <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-50 dark:bg-slate-950/20 border border-slate-150 dark:border-slate-850 rounded-xl select-none">
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<BoldOutlined />} 
                    onClick={() => insertAtCursor('**', '**')}
                    className="font-bold text-slate-650 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
                  />
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<ItalicOutlined />} 
                    onClick={() => insertAtCursor('*', '*')}
                    className="font-bold text-slate-650 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
                  />
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<UnderlineOutlined />} 
                    onClick={() => insertAtCursor('<u>', '</u>')}
                    className="font-bold text-slate-650 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
                  />
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<StrikethroughOutlined />} 
                    onClick={() => insertAtCursor('~~', '~~')}
                    className="font-bold text-slate-650 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
                  />
                  <Divider type="vertical" className="border-slate-200 dark:border-slate-800 h-4 m-0 mx-1" />
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<LinkOutlined />} 
                    onClick={() => insertAtCursor('[', '](url)')}
                    className="font-bold text-slate-650 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
                  />
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<UnorderedListOutlined />} 
                    onClick={() => insertAtCursor('\n- ', '')}
                    className="font-bold text-slate-650 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
                  />
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<OrderedListOutlined />} 
                    onClick={() => insertAtCursor('\n1. ', '')}
                    className="font-bold text-slate-650 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
                  />
                  <Divider type="vertical" className="border-slate-200 dark:border-slate-800 h-4 m-0 mx-1" />
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<AlignLeftOutlined />} 
                    onClick={() => toast.success('Paragraph alignment toggled')}
                    className="font-bold text-slate-650 hover:bg-slate-200 dark:text-slate-300 dark:hover:bg-slate-800"
                  />
                </div>
                       {/* Text Editor Area */}
                <div className="flex-1 flex flex-col">
                  <textarea
                    id="progress-note-editor"
                    value={noteText}
                    onChange={e => setNoteText(e.target.value)}
                    readOnly={isNoteFinal}
                    className={`flex-1 w-full min-h-[350px] p-4 border rounded-2xl font-sans text-sm resize-none leading-relaxed transition-all focus:outline-none ${
                      isNoteFinal 
                        ? 'bg-slate-50 dark:bg-slate-950/60 border-slate-200 dark:border-slate-800/80 text-slate-400 dark:text-slate-500 cursor-not-allowed' 
                        : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:ring-1 focus:ring-[#8C4BFF] focus:border-[#8C4BFF]'
                    }`}
                    placeholder="Start writing progress notes here..."
                  />
                </div>

                {/* Bottom Footer Actions */}
                <div className="flex justify-end items-center gap-3 pt-3 border-t border-slate-150 dark:border-slate-850 select-none">
                  {isNoteFinal ? (
                    <Button 
                      onClick={() => {
                        store.updateConsultation(existingNoteForLock.id, { status: 'Draft' })
                        toast.success('Note reopened for editing!')
                      }}
                      style={{ backgroundColor: '#F59E0B', borderColor: '#F59E0B' }}
                      className="rounded-xl font-bold h-10 px-6 text-white hover:opacity-90 animate-pulse-subtle"
                    >
                      Reopen Note
                    </Button>
                  ) : (
                    <>
                      <Button 
                        onClick={handleSaveDraft}
                        className="rounded-xl font-bold h-10 px-5 text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-750 dark:hover:bg-slate-700"
                      >
                        Save Draft
                      </Button>
                      <Button 
                        type="primary" 
                        onClick={handleSaveFinal}
                        style={{ backgroundColor: '#0E1B33', borderColor: '#0E1B33' }}
                        className="rounded-xl font-bold h-10 px-6 text-white hover:opacity-90"
                      >
                        Save as Final
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </Tabs.TabPane>

          {/* TAB 2: EXERCISES & TREATMENT PLAN PRESCRIPTION */}
          <Tabs.TabPane tab={<span><HeartOutlined /> Exercises & Treatment Plans</span>} key="exercises">
            <div className="p-4 space-y-6">
              <h4 className="font-black text-sm text-[#0E1B33] dark:text-white uppercase tracking-wider">Assign Rehabilitation Exercise Program</h4>
              
              <Form form={exerciseForm} layout="vertical" onFinish={handlePrescribeExercises}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Left Column: Form Details */}
                  <div className="space-y-4">
                    <Form.Item name="programName" label={<span className="text-xs font-semibold text-slate-500">Program / Treatment Plan Title</span>} rules={[{ required: true, message: 'Enter plan title' }]}>
                      <Input placeholder="e.g. Spine Mobilisation & Core Recovery v3" className="rounded-xl h-10" />
                    </Form.Item>
                    
                    <div className="p-4 bg-slate-50/50 dark:bg-slate-950/20 border border-slate-150 dark:border-slate-850 rounded-2xl space-y-3">
                      <h5 className="font-extrabold text-xs text-slate-400 uppercase tracking-wider mb-2">Exercise Video & Workout Reps</h5>
                      
                      <Form.Item name="exVideo1" label={<span className="text-[11px] font-bold text-slate-500">Video Demonstration Link / Title</span>} rules={[{ required: true, message: 'Select video demo' }]}>
                        <Select placeholder="Choose demo video..." className="rounded-xl">
                          <Option value="Cat-Cow Lumbar Mobilisation">Cat-Cow Lumbar Mobilisation</Option>
                          <Option value="Prone Bird-Dog holds">Prone Bird-Dog holds</Option>
                          <Option value="Supine Dead Bug core press">Supine Dead Bug core press</Option>
                          <Option value="Scapular Pull-Down isometric">Scapular Pull-Down isometric</Option>
                          <Option value="Cognitive focus relaxation guide">Cognitive focus relaxation guide</Option>
                        </Select>
                      </Form.Item>

                      <div className="grid grid-cols-3 gap-3">
                        <Form.Item name="sets1" label={<span className="text-[11px] font-bold text-slate-500">Sets</span>}>
                          <InputNumber min={1} max={10} className="w-full rounded-xl" placeholder="3" />
                        </Form.Item>
                        <Form.Item name="reps1" label={<span className="text-[11px] font-bold text-slate-500">Reps</span>}>
                          <InputNumber min={1} max={30} className="w-full rounded-xl" placeholder="10" />
                        </Form.Item>
                        <Form.Item name="freq1" label={<span className="text-[11px] font-bold text-slate-500">Frequency</span>}>
                          <Input className="rounded-xl" placeholder="Daily" />
                        </Form.Item>
                      </div>

                      <Form.Item name="inst1" label={<span className="text-[11px] font-bold text-slate-500">Specific Treatment Instructions</span>}>
                        <TextArea rows={2} placeholder="e.g. Move slowly through pain-free range of motion..." className="rounded-xl" />
                      </Form.Item>
                    </div>

                    <div className="flex justify-end pt-3">
                      <Button type="primary" htmlType="submit" style={{ backgroundColor: '#10B981', borderColor: '#10B981' }} className="rounded-xl font-bold h-10 px-6 text-white">
                        Assign Program
                      </Button>
                    </div>
                  </div>

                  {/* Right Column: Exercise Library / Compliance Mock list */}
                  <div className="space-y-4">
                    <h5 className="font-extrabold text-xs text-slate-400 uppercase tracking-wider block">Assigned Programs & Compliance</h5>
                    <div className="space-y-3">
                      {[
                        { name: 'Lumbar Spine Strengths & Core Stability v2', date: '02/06/2026', practitioner: 'Dr. Sarah Jenkins', status: 'Completed', comp: 92 },
                        { name: 'Neck & Upper Trapezius Stretching', date: '12/05/2026', practitioner: 'Dr. Sarah Jenkins', status: 'Viewed', comp: 45 }
                      ].map((item, idx) => (
                        <div key={idx} className="p-4 bg-white dark:bg-slate-950 border border-slate-150 rounded-2xl space-y-3 text-xs shadow-sm">
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="font-bold text-slate-800 block">{item.name}</span>
                              <span className="text-[9px] text-slate-400 font-semibold block mt-0.5">Assigned by {item.practitioner} on {item.date}</span>
                            </div>
                            <Tag color={item.status === 'Completed' ? 'success' : 'processing'} className="m-0 border-none rounded-lg text-[9px] font-bold uppercase">{item.status}</Tag>
                          </div>
                          
                          {/* Compliance Bar */}
                          <div>
                            <div className="flex justify-between text-[10px] text-slate-400 font-semibold mb-1">
                              <span>Patient Compliance Rate:</span>
                              <span>{item.comp}%</span>
                            </div>
                            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                              <div className="bg-[#10B981] h-full" style={{ width: `${item.comp}%` }} />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Form>
            </div>
          </Tabs.TabPane>

          {/* TAB 3: REFERRALS GENERATOR */}
          <Tabs.TabPane tab={<span><BranchesOutlined /> Referrals</span>} key="referrals">
            <div className="p-4 space-y-6">
              <h4 className="font-black text-sm text-[#0E1B33] dark:text-white uppercase tracking-wider">Draft Referral Letter</h4>
              
              <Form form={referralForm} layout="vertical" onFinish={handleSendReferral}>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                  {/* Left Column: Parameters Form */}
                  <div className="md:col-span-2 space-y-4">
                    <Form.Item name="recipient" label={<span className="text-xs font-semibold text-slate-500">Refer to Provider (GP, Specialist, Clinic)</span>} rules={[{ required: true, message: 'Please select provider' }]}>
                      <Select placeholder="Choose recipient..." className="rounded-xl">
                        <Option value="Dr. Arthur Conan (GP)">Dr. Arthur Conan (GP)</Option>
                        <Option value="Dr. David Bruce (Specialist)">Dr. David Bruce (Specialist)</Option>
                        <Option value="Melbourne Allied Health">Melbourne Allied Health</Option>
                        <Option value="Southside Radiology (Imaging)">Southside Radiology (Imaging)</Option>
                      </Select>
                    </Form.Item>

                    <Form.Item name="recipientType" label={<span className="text-xs font-semibold text-slate-500">Referral Type / Facility</span>}>
                      <Radio.Group className="flex flex-col gap-2">
                        <Radio value="GP">General Practitioner (GP)</Radio>
                        <Radio value="Specialist">Specialist Doctor</Radio>
                        <Radio value="Allied Health">Allied Health Provider</Radio>
                        <Radio value="Imaging">Imaging (MRI, X-Ray)</Radio>
                      </Radio.Group>
                    </Form.Item>

                    <div className="pt-2">
                      <Button 
                        type="primary" 
                        onClick={handleDraftReferralLetter}
                        style={{ backgroundColor: '#8C4BFF', borderColor: '#8C4BFF' }}
                        className="w-full rounded-xl font-bold h-10 text-white"
                      >
                        Draft Referral Letter with AI
                      </Button>
                    </div>
                  </div>

                  {/* Right Column: AI Draft preview */}
                  <div className="md:col-span-3 space-y-4 flex flex-col justify-between">
                    <Form.Item name="letter" label={<span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">AI Referral Draft Letter</span>} rules={[{ required: true, message: 'Referral letter text is required' }]}>
                      <TextArea rows={12} className="rounded-2xl" placeholder="Referral letter draft details will appear here..." />
                    </Form.Item>
                    
                    <div className="flex justify-end gap-2 pt-2">
                      <Button onClick={() => referralForm.resetFields()} className="rounded-xl font-bold border-slate-200">Reset</Button>
                      <Button type="primary" htmlType="submit" style={{ backgroundColor: '#0E1B33', borderColor: '#0E1B33' }} className="rounded-xl font-bold h-10 px-6 text-white">
                        Approve & Send Referral
                      </Button>
                    </div>
                  </div>
                </div>
              </Form>
            </div>
          </Tabs.TabPane>

          {/* TAB 4: BILLING & INVOICING */}
          <Tabs.TabPane tab={<span><DollarOutlined /> Billing</span>} key="billing">
            <div className="p-4 space-y-4">
              <h4 className="font-black text-sm text-[#0E1B33] dark:text-white uppercase tracking-wider">Create Invoice & Claim Claims</h4>
              
              {!store.practitionerBillingEnabled ? (
                <div className="p-6 bg-red-50/20 border border-red-100 rounded-2xl text-center space-y-3">
                  <LockOutlined style={{ fontSize: 28, color: '#EF4444' }} />
                  <h4 className="font-extrabold text-sm text-slate-800 m-0">Invoicing Access Restricted</h4>
                  <p className="text-slate-400 text-xs mt-1">
                    Your practitioner profile is not authorized to draft invoices directly. Clinic manager has disabled billing control permissions.
                  </p>
                </div>
              ) : (
                <Form form={invoiceForm} layout="vertical" onFinish={handleCreateInvoice}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Invoice Inputs */}
                    <div className="space-y-4">
                      <Form.Item name="serviceName" label={<span className="text-xs font-semibold text-slate-500">Service Offered</span>} rules={[{ required: true }]}>
                        <Select placeholder="Choose consultation service item..." className="rounded-xl">
                          {store.services.map(s => (
                            <Option key={s.id} value={s.name}>{s.name} (${s.price} AUD)</Option>
                          ))}
                        </Select>
                      </Form.Item>

                      <div className="grid grid-cols-2 gap-4">
                        <Form.Item name="fundingType" label={<span className="text-xs font-semibold text-slate-500">Funding Scheme</span>} initialValue="NDIS">
                          <Select className="rounded-xl">
                            <Option value="NDIS">NDIS</Option>
                            <Option value="EPC">EPC Medicare</Option>
                            <Option value="Private">Private Claims</Option>
                            <Option value="DVA">DVA (Veterans)</Option>
                            <Option value="WorkCover">WorkCover Claims</Option>
                          </Select>
                        </Form.Item>

                        <Form.Item name="paymentTerms" label={<span className="text-xs font-semibold text-slate-500">Payment Terms</span>} initialValue="7 Days">
                          <Select className="rounded-xl">
                            <Option value="Due Immediately">Due Immediately</Option>
                            <Option value="7 Days">7 Days</Option>
                            <Option value="14 Days">14 Days</Option>
                          </Select>
                        </Form.Item>
                      </div>

                      <div className="flex justify-end pt-3">
                        <Button type="primary" htmlType="submit" style={{ backgroundColor: '#EC4899', borderColor: '#EC4899' }} className="rounded-xl font-bold h-10 px-6 text-white">
                          Create & Sent Invoice
                        </Button>
                      </div>
                    </div>

                    {/* Funding summary card */}
                    <div className="bg-[#EC4899]/5 border border-[#EC4899]/10 p-5 rounded-2xl flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] uppercase font-black text-[#EC4899] block mb-2">Funding Limit Summary</span>
                        <div className="space-y-3.5 text-xs font-semibold text-slate-500">
                          <div className="flex justify-between">
                            <span>EPC Medicare Limit:</span>
                            <span className="text-slate-800">5 Sessions / Yr</span>
                          </div>
                          <div className="flex justify-between">
                            <span>NDIS Funding status:</span>
                            <span className="text-slate-800">Plan Managed</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Client Allocated Sessions:</span>
                            <span className="text-slate-800">{patient.sessionsAllocated || 10} Sessions</span>
                          </div>
                          <div className="flex justify-between text-slate-800">
                            <span>Sessions Used:</span>
                            <span className="font-extrabold text-blue-550">{patient.sessionsUsed || 4} Sessions</span>
                          </div>
                          <Divider className="my-1 border-slate-200" />
                          <div className="flex justify-between text-sm font-black text-slate-850">
                            <span>Sessions Remaining:</span>
                            <span className="text-[#EC4899]">{(patient.sessionsAllocated || 10) - (patient.sessionsUsed || 4)} Sessions</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-3 bg-yellow-50/50 border border-yellow-100 rounded-xl text-[10.5px] text-yellow-700 font-semibold mt-4">
                        Low Session Alert: Automatic reminders are triggered to receptionist for NDIS plan renewal when remaining sessions count is 2 or less.
                      </div>
                    </div>
                  </div>
                </Form>
              )}
            </div>
          </Tabs.TabPane>
        </Tabs>
      </Card>
    </div>
  )
}
