import React from 'react'
import { Card, Table, Tag, Button } from 'antd'
import { toast } from 'react-hot-toast'

export default function PractitionerExercises() {
  const list = [
    { key: '1', name: 'Double leg calf raises', reps: '3 sets x 15 reps', dur: '5 mins', type: 'Strength' },
    { key: '2', name: 'Lumbar stretching extensions', reps: 'Hold 30s x 5 reps', dur: '8 mins', type: 'Flexibility' },
    { key: '3', name: 'Ankle resistance bands flexion', reps: '3 sets x 12 reps', dur: '6 mins', type: 'Strength' },
    { key: '4', name: 'Hamstring eccentric stretches', reps: '3 sets x 10 reps', dur: '7 mins', type: 'Stretching' },
  ]

  return (
    <Card
      className="border border-slate-100 rounded-2xl shadow-sm overflow-hidden"
      title={<span className="font-bold text-slate-800 text-base">Physiotherapy Exercises Library Catalogue</span>}
      extra={<Button type="primary" onClick={() => toast.success('Open add exercise catalog form')} className="rounded-xl text-xs font-bold" style={{ backgroundColor: '#8C4BFF', border: 'none' }}>+ Add Exercise</Button>}
    >
      <Table
        dataSource={list}
        pagination={false}
        columns={[
          { title: 'Exercise Program name', dataIndex: 'name', render: (t) => <span className="font-bold text-slate-800 text-xs">{t}</span> },
          { title: 'Standard Reps', dataIndex: 'reps' },
          { title: 'Recommended Duration', dataIndex: 'dur' },
          { title: 'Classification', dataIndex: 'type', render: (t) => <Tag className="rounded-full border-none font-bold text-[9px] px-2.5 py-0.5 bg-slate-100 text-slate-500">{t}</Tag> },
          {
            title: '',
            key: 'action',
            align: 'right',
            render: (_, record) => <Button size="small" className="rounded-lg" onClick={() => toast.success(`Assigned ${record.name} to patient directory list!`)}>Assign to Client</Button>
          }
        ]}
      />
    </Card>
  )
}
