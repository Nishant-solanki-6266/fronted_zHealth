import React, { useState, useRef, useEffect } from 'react'
import { Card, Table, Select, Button, Input, Progress } from 'antd'
import {
  AudioOutlined,
  AudioMutedOutlined,
  SyncOutlined
} from '@ant-design/icons'
import { useClinicStore } from '../../../../store/clinicStore'
import { toast } from 'react-hot-toast'

const { Option } = Select

export default function PractitionerNotesReview() {
  const store = useClinicStore()
  const [drafts, setDrafts] = useState([
    { id: '1', client: 'John Miller', reason: 'Low Back Pain Assessment', note: 'Subjective: Patient reports lumbar pain rated 6/10 following lifting activity. Objective: Active flexion limited to 45 degrees. Straight leg raise causes tight hamstring reactions at 60 degrees.' },
    { id: '2', client: 'Alice Smith', reason: 'Pediatric Intake Review', note: 'Subjective: Mother reports Alice has improved balance during play. Objective: Able to stand on single leg for 8 seconds. Reaction parameters show standard motor reflexes.' },
    { id: '3', client: 'James Davis', reason: 'Lumbar Spine Adjustment follow-up', note: 'Subjective: Pain symptoms reduced to 2/10. Objective: Full lumbar range of motion recovered. Extension movements cause no radiating pain discomfort.' },
  ])

  const [selectedPatientId, setSelectedPatientId] = useState(store.patients[0]?.id || '')
  const [isRecording, setIsRecording] = useState(false)
  const [recordDuration, setRecordDuration] = useState(0)
  const [isCompiling, setIsCompiling] = useState(false)
  const [compileStep, setCompileStep] = useState('')
  const timerRef = useRef(null)

  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setRecordDuration(prev => prev + 1)
      }, 1000)
    } else {
      clearInterval(timerRef.current)
      setRecordDuration(0)
    }
    return () => clearInterval(timerRef.current)
  }, [isRecording])

  const formatDuration = (sec) => {
    const mins = Math.floor(sec / 60)
    const secs = sec % 60
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
  }

  const handleStartRecording = () => {
    setIsRecording(true)
    toast.success('Microphone active — simulating voice transcription...')
  }

  const handleStopAndCompile = () => {
    setIsRecording(false)
    setIsCompiling(true)
    setCompileStep('Whisper API: Transcribing voice stream to text...')

    setTimeout(() => {
      setCompileStep('GPT-4o: Compiling dictation into clinical SOAP note...')
      
      setTimeout(() => {
        const patient = store.patients.find(p => p.id === selectedPatientId)
        const name = patient ? patient.name : 'Unnamed Patient'
        const newDraft = {
          id: `draft_${Date.now()}`,
          client: name,
          reason: 'Voice Dictation SOAP Note',
          note: `Subjective: Patient reports positive progress. Symptoms are decreasing during general rehab exercises. Objective: Range of motion shows a 15% increase compared to baseline. Physical resistance threshold has improved. Assessment: Rehabilitation on track. Plan: Continue current exercise routine and review in 14 days.`
        }
        setDrafts(prev => [newDraft, ...prev])
        setIsCompiling(false)
        setCompileStep('')
        toast.success(`SOAP notes compiled successfully for ${name}!`)
      }, 1500)
    }, 1500)
  }

  return (
    <div className="space-y-6">
      
      {/* Mic Dictation Recorder Panel */}
      <Card className="border border-slate-100 rounded-2xl shadow-sm" title={<span className="font-bold text-slate-800 text-base">AI Clinical Dictation Recorder</span>}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="space-y-4">
            <div>
              <span className="text-xs font-bold text-slate-550 block mb-1.5">Select Client for Dictation</span>
              <Select 
                value={selectedPatientId} 
                onChange={setSelectedPatientId}
                className="w-full h-10 flex items-center"
              >
                {store.patients.map(p => (
                  <Option key={p.id} value={p.id}>{p.name} (DOB: {p.dob})</Option>
                ))}
              </Select>
            </div>

            <div className="flex items-center gap-3">
              {!isRecording && !isCompiling && (
                <Button 
                  type="primary"
                  onClick={handleStartRecording}
                  icon={<AudioOutlined />}
                  style={{ backgroundColor: '#EF4444', borderColor: '#EF4444' }}
                  className="rounded-xl h-10 font-bold px-4 flex items-center gap-1.5"
                >
                  Start Recording
                </Button>
              )}

              {isRecording && (
                <Button 
                  type="primary"
                  onClick={handleStopAndCompile}
                  icon={<AudioMutedOutlined />}
                  style={{ backgroundColor: '#0F172A', borderColor: '#0F172A' }}
                  className="rounded-xl h-10 font-bold px-4 flex items-center gap-1.5 animate-pulse"
                >
                  Stop & Compile SOAP
                </Button>
              )}

              {isCompiling && (
                <div className="flex items-center gap-2 text-xs font-bold text-[#8C4BFF]">
                  <SyncOutlined spin />
                  <span>{compileStep}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col items-center justify-center p-4 bg-slate-50 border border-slate-100 rounded-2xl h-36 relative overflow-hidden">
            {isRecording ? (
              <>
                {/* Recording wave visualizer */}
                <div className="flex items-end gap-1 mb-2 h-10">
                  {[...Array(10)].map((_, i) => (
                    <div 
                      key={i} 
                      className="w-1.5 bg-[#EF4444] rounded-full transition-all duration-150 animate-bounce"
                      style={{ 
                        height: `${Math.floor(Math.random() * 32) + 8}px`,
                        animationDelay: `${i * 0.05}s`
                      }} 
                    />
                  ))}
                </div>
                <span className="text-xs font-bold text-red-500 flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-ping" />
                  <span>Recording {formatDuration(recordDuration)}</span>
                </span>
              </>
            ) : isCompiling ? (
              <div className="text-center space-y-2">
                <Progress percent={compileStep.includes('GPT-4o') ? 75 : 30} showInfo={false} strokeColor="#8C4BFF" className="w-40 mx-auto" />
                <span className="text-[11px] font-bold text-[#8C4BFF] animate-pulse block">Analyzing dictation tracks...</span>
              </div>
            ) : (
              <div className="text-center text-slate-400 space-y-1">
                <AudioOutlined style={{ fontSize: 24 }} />
                <span className="block text-xs font-bold text-slate-450">Microphone Standby</span>
                <span className="block text-[10px] text-slate-400">Select patient and click record to start clinical dictation</span>
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Drafts board */}
      <Card className="border border-slate-100 rounded-2xl shadow-sm overflow-hidden" title={<span className="font-bold text-slate-800 text-base">AI SOAP Notes Approval Board</span>}>
        <Table
          dataSource={drafts}
          rowKey="id"
          pagination={false}
          columns={[
            { title: 'Client Tenant', dataIndex: 'client', render: (t) => <span className="font-bold text-slate-800 text-xs">{t}</span>, width: '20%' },
            { title: 'Treatment Cause', dataIndex: 'reason', render: (t) => <span className="font-semibold text-slate-500 text-xs">{t}</span>, width: '20%' },
            { title: 'AI Dictated SOAP Notes Draft', dataIndex: 'note', render: (text, record) => (
              <Input.TextArea
                value={text}
                onChange={e => {
                  const val = e.target.value
                  setDrafts(prev => prev.map(d => d.id === record.id ? { ...d, note: val } : d))
                }}
                rows={3}
                className="text-xs text-slate-650 font-semibold"
              />
            ), width: '45%' },
            {
              title: '',
              key: 'action',
              align: 'right',
              width: '15%',
              render: (_, record) => (
                <Button
                  type="primary"
                  onClick={() => {
                    setDrafts(prev => prev.filter(d => d.id !== record.id))
                    toast.success(`SOAP notes approved and saved to client record for ${record.client}!`)
                  }}
                  style={{ backgroundColor: '#0E1B33', color: 'white', border: 'none' }}
                  className="rounded-lg text-xs font-bold"
                >
                  Approve & Sign
                </Button>
              ),
            },
          ]}
        />
      </Card>
    </div>
  )
}
